//
//  WeSplitApp.swift
//  WeSplit
//
//  Created by sanika chavan on 26/07/21.
//

import SwiftUI

@main
struct WeSplitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
